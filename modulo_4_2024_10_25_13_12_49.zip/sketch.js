function setup() { //função "setup"
  createCanvas(400, 400); //criando o cenário
}

function draw() {
  background("white"); //cor do fundo
  fill("black"); //cor das letras
  textSize(60); //tamanho do texto
  textAlign(CENTER, CENTER); //função para alinhar o texto no centro

  let maximo = width; //variável "maximo"
  let minimo = 0; //variável "minimo"

  let palavra = "Angelina"; //criando a variável "palavra"
  let quantidade = map(mouseX, 0, width, 1, palavra.length); //quantidade de letras que serão utilizadas, sempre vai iniciar com o "A"
  let parcial = palavra.substring(0, quantidade); //separando as letras
  text(parcial, 200, 200); //posição do texto
    
  }
  
  